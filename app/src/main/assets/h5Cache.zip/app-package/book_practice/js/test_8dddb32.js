/**
 * Copyright (c) 2014-2017 Zuoyebang, All rights reseved.
 * @fileoverview 绘本-读书答题页面
 * @author RongZhiqiang | RongZhiqiang@zuoyebang.com
 * @version 1.0 | 2018-03-21 | RongZhiqiang   // 初始版本
 **/
"use strict";

var $ = require('common:widget/lib/zepto/zepto'),
  Swiper = require('practice:widget/swiper/swiper'),
  zybLog = require('common:widget/util/zybLog'),
  animation = require('common:widget/util/animation'),
  JSmart = require('common:widget/lib/jsmart/jsmart'),
  renderTpl = "{%if $result.answer%}\n<ul class=\"tabList\">\n{%foreach $result.answer as $list%}\n<li class=\"tabItem {%if $list.r == 1%}isRight{%else%}isWrong{%/if%}\">{%$list@index+1%}</li>\n{%/foreach%}\n</ul>\n{%/if%}\n<div class=\"swiper-container\">\n<div class=\"swiper-wrapper\">\n{%foreach $result.data.questions as $list%}\n<div class=\"swiper-slide\">\n<div class=\"question\">\n<p class=\"source clearfix\">出自《{%$result.data.bookName|f_escape_xml%}》<span class=\"rateText\"><i id=\"rateNum\">{%$list@index+1%}</i>/{%$result.data.questions|count|f_escape_xml%}题</span></p>\n<p class=\"questionText\">\n{%if $list.audio!=\"http://www.zuoyebang.com\"%}\n<span class=\"playAudio\" data-src=\"{%$list.audio|f_escape_xml%}\">播放</span>\n{%/if%}\n{%$list.content|escape:none%}\n</p>\n<ul>\n{%foreach $list.selected[$result.index-1] as $items%}\n<li class=\"selectItem\" data-isanswer=\"{%$items.isAnswer|f_escape_xml%}\" data-content=\"{%$items.content|f_escape_xml%}\" data-type=\"{%$items.type|f_escape_xml%}\">\n<div class=\"a-tag\">{%if $items@index == 0%}A{%elseif $items@index == 1%}B{%else%}C{%/if%}</div>\n{%if $items.type == 2%}\n<div class=\"a-con imgType\"\r\n                 style=\"background-image: url({%$items.content|f_escape_xml%})\"></div>\n{%else%}\n<div class=\"a-con\">{%$items.content|f_escape_xml%}</div>\n{%/if%}\n</li>\n{%/foreach%}\n</ul>\n</div>\n</div>\n{%/foreach%}\n</div>\n<div class=\"btnBox\">\n<span id=\"prevQBtn\">上一题</span>\n<span id=\"nextQBtn\">下一题</span>\n</div>\n</div>",
  attachFastClick = require('mcommon:widget/lib/fastclick/fastclick'),
  hybridApi = require('common:widget/util/hybrid');

var App = {},
  qType = Math.random() < 0.33 ? 1 : Math.random() > 0.66 ? 2 : 3,
  answerArr = [],
  timer,
  swiper,
  uid = '',
  bookid = '',
  hasAnswer = '';

attachFastClick(document.body);
App.init = function () {
  hasAnswer = App.getQueryString('hasAnswer') == 1 ? 1 : 0;
  hybridApi('getBookTest', '', function (res) {
    if (res.result) {
      bookid = res.result.bookId;
      var localData = localStorage.getItem('localData'),
        answerData = JSON.parse(localData),
        _answer = answerData && answerData.answer && answerData.answer instanceof Array && answerData.answer.length > 0 ? answerData.answer : [];
      var innerHtml = renderTpl.fetch({
        result: {
          data: res.result,
          index: hasAnswer == 1 ? answerData.qType : qType,
          answer: _answer
        }
      });
      $('#wrap').html(innerHtml);

      if (hasAnswer == 1) {
        $('.swiper-slide').each(function () {
          var _this = $(this),
            _index = _this.index(),
            setData = JSON.parse(localData);
          if (setData && setData.answer instanceof Array && setData.answer.length > 0) {
            var userSelect = _this.find('.selectItem').eq(setData.answer[_index].index),
              _isRight = userSelect.data('isanswer');
            if (_isRight == 1) {
              userSelect.addClass('isRight');
            } else {
              userSelect.addClass('isWrong');
            }
          }
          _this.find(".selectItem[data-isanswer='1']").addClass('isRight');
        });

        $('.tabList li:first').addClass('isActive');
        $('.tabList').show();
        $('.btnBox').show();
        $('.progressBar').hide();
      } else {
        $('.tabList').hide();
        $('.btnBox').hide();
        $('.progressBar').show();
      }

      var _index = App.getQueryString('index') || 0;
      swiper = new Swiper('.swiper-container', {
        direction: 'horizontal',
        speed: 500,
        noSwipingClass: 'swiper-slide',
        nextButton: '#nextQBtn',
        prevButton: '#prevQBtn',
        autoHeight: false,
        initialSlide: hasAnswer == 1 ? _index : 0,
        onInit: function (swiper) {
          App.getQueryString('hasAnswer') != 1 && App.countdown();
          $('#prevQBtn').addClass("disabled");
          hybridApi('setBookTitle', {index: 0});

          if (hasAnswer == 0) {
            App.playAudio();
          };
        },
        onSlideChangeStart: function (swiper) {
          clearInterval(timer);
          hasAnswer != 1 && App.countdown();
          hybridApi('webAudioPlay', {url: '', action: 0}, function () {});
          if (hasAnswer == 1) {
            $('.tabList li').eq(swiper.activeIndex).addClass('isActive').siblings('li').removeClass('isActive');
          } else {
            hybridApi('setBookTitle', {index: swiper.activeIndex});
            $('#progressId').removeClass('warning');
          }
        },
        onSlideChangeEnd: function () {
          if (hasAnswer == 0) {
            App.playAudio();
          }
        }
      });
    }
  });
  hybridApi('getuserinfo', {}, function (res) {
    uid = res.uid;
    zybLog.send({
      type: 'read-world-showpv',
      module: 'plat-activity',
      page: 'book-practice',
      uid: uid,
      bookid: bookid
    });
  });
  App.bind();
};

App.bind = function () {
  $('#wrap').on('click', '.selectItem', function () {
    if (hasAnswer == 0) {
      var _this = $(this),
        _index = _this.index(),
        _data = {},
        _isRight = _this.data('isanswer'),
        _cname = _isRight == 1 ? 'isRight' : 'isWrong',
        _r = _isRight == 1 ? 1 : 0;

      if (!_this.hasClass('disabled') && !_this.hasClass('isRight') && !_this.hasClass('isWrong')) {
        _data.r = _r;
        _data.index = _index
        _this.removeClass('isRight isWrong').addClass(_cname);
        answerArr.push(_data);
        if (_isRight == 1) {
          hybridApi('playEffects', {type: 3});
        } else {
          hybridApi('playEffects', {type: 4});
        }
        _this.addClass('disabled').siblings('li').addClass('disabled');
        var newIndex = parseInt(swiper.activeIndex) + 1,
          _len = swiper.slidesGrid.length;
        if (newIndex == _len) {
          App.submit();
        }

        zybLog.send({
          type: 'read-world-selectClick',
          module: 'plat-activity',
          page: 'book-practice',
          uid: uid,
          bookid: bookid
        });

        var clickTimer = setTimeout(function () {
          swiper.slideNext();
          clearTimeout(clickTimer);
        }, 300);
      }
    }
  });

  $('#wrap').on('click', '.tabItem', function () {
    var _this = $(this),
      _index = _this.index();
    swiper.slideTo(_index);
  });

  $('#wrap').on('click', '.playAudio', function () {
    var _this = $(this),
      _src = _this.data('src');
    if (!_this.hasClass('playing')) {
      _this.addClass('playing');
      zybLog.send({
        type: 'read-world-audioClick',
        module: 'plat-activity',
        page: 'book-practice',
        uid: uid,
        bookid: bookid
      });
      hybridApi('webAudioPlay', {url: _src, action: 1}, function () {
        _this.removeClass('playing');
      });
    }
  });
};

App.submit = function () {
  var data = {
    qType: qType,
    answer: answerArr
  }

  localStorage.setItem('localData', JSON.stringify(data))
  hybridApi('subBookTestAnswer', {results: answerArr})
};

//倒计时器
App.countdown = function () {
  var lv = 6,
    startTime = +new Date(),
    endTime = startTime + 1000 * 10 * lv,
    localStartTime = startTime - new Date().getTime(),
    $progressId = $('#progressId')[0];
  timer = setInterval(function () {
    var _nowTime = new Date().getTime() + localStartTime,
      _endTime = new Date(endTime).getTime(),
      lefttime = (_endTime - _nowTime) / 1000;
    if (lefttime >= 0) {
      var m = parseInt(lefttime / 60 % 60),
        s = (lefttime % 60);
      $("#minute").html(m < 10 ? '0' + m : m);
      $("#second").html(Math.round(s) < 10 ? '0' + Math.round(s) : Math.round(s));
      if (Math.round(s) <= 5) {
        hybridApi('playEffects', {type: 12});
        if (!$('#progressId').hasClass('warning')) {
          $('#progressId').addClass('warning');
        };
      }
    } else {
      $("#second").html('00');
      clearInterval(timer);

      var data = {
        r: 0,
        index: $('.swiper-slide-active li[data-isanswer="1"]').index()
      };
      answerArr.push(data);

      var newIndex = parseInt(swiper.activeIndex) + 1,
        _len = swiper.slidesGrid.length;
      if (newIndex == _len) {
        App.submit();
      }
      swiper.slideNext();
    }
  }, 1000);

  animation({
    duration: 1000 * 10 * lv,
    delay: 0,
    easing: 'linear',
    onStart: function (progress) {
    },
    onStep: function (progress) {
      var value = (1 - progress) * 100;
      $progressId.style.width = value + '%';
    },
    onComplete: function (progress) {
    }
  });
};

//获取URL参数
App.getQueryString = function (name) {
  var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
  var r = window.location.search.substr(1).match(reg);
  if (r != null) {
    return unescape(r[2]);
  }
  return "";
};

App.playAudio = function () {
  if($('.swiper-slide-active .playAudio').length > 0){
    var $playAudio = $('.swiper-slide-active .playAudio').eq(0),
      _src = $playAudio.data('src');
    $playAudio.addClass('playing');
    hybridApi('webAudioPlay', {url: _src, action: 1}, function () {
      $playAudio.removeClass('playing');
    });
  } 
}

App.init();

window.stopPlay = function () {
  clearInterval(timer);
  hybridApi('webAudioPlay', {url: '', action: 0});
};

