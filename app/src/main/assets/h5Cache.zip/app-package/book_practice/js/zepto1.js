/**
 * Copyright (c) 2014-2017 Zuoyebang, All rights reserved.
 * @fileoverview zepto 预加载文件。
 * @author WangWenshu | wangwenshu@zuoyebang.com
 * @version 1.0 | 2016-07-04 | WangWenshu    // 初始版本。
 *
 * @description    // 附加说明。
 *   1) 本文件用于预加载 zepto，通过在 m-framework.tpl 基模板中优前引用，达到预先加载的目的。
 *   2) zepto 脚本自身在执行时完成向 window 挂载 $ 的操作。
 */

require('common:widget/lib/zepto/zepto.js');