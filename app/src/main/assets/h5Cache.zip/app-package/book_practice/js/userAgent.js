define('mcommon:widget/util/userAgent.js', function(require, exports, module){ 'use strict';

/**
 * Copyright (c) 2014-2017 Zuoyebang, All rights reserved.
 * @fileoverview 有关 userAgent 的扩展工具方法
 * @author wangyan01 | wangyan01@zuoyebang.com
 * @version 1.0 | 2014-07-11 | wangyan01    // 初始版本。
 * 
 * @description   // 附加说明。
 *  客户端会添加自定义 UA 内容，类似：
 *  ... homework homework_vc/158 homework_vcname/8.4.2 
 *      homework_cuid/6bc0a5afda9abbfac9fb4166a46b841568aad257 homework_token/2_XPXQH3c5HRPtFHkSwi3sCCURmT25QfxM ...
 * 
 * @method get(key)         // 方法：按自定义 UA 的规则获取相关值。
 *   @param key {String}            // 参数：key（必选）
 *   @return {String}               // 返回：value
 * 
 * @example
    var uaExt = require('common:widget/util/userAgent.js');

    uaExt.get('vc');                 // 获取 ua 中的 homework_vc 。
 */

var uaExt = {},
    _validKeyReg = new RegExp('homework_');

uaExt._isKeyValid = function (key) {
  return (/homework/i.test(navigator.userAgent) && _validKeyReg.test(key)
  );
};

uaExt.getRaw = function (key) {
  if (uaExt._isKeyValid(key)) {
    return null;
  }
  var reg = new RegExp('homework_' + key + '\/([^\\s]*)'),
      result = reg.exec(navigator.userAgent);

  return result && result[1] || null;
};

uaExt.get = function (key) {
  var value = uaExt.getRaw(key);
  return value ? decodeURIComponent(value) : null;
};

module.exports = uaExt; 
});